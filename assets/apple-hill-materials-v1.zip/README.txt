APPLE HILL MATERIAL LIBRARY 1.0.0

12 original photo-informed, periodic material sets for the Apple Hill digital twin.
These are authored procedural approximations, not photographic scans. No source
image, annotation or shadow is projected onto a model. The source-photo hashes
and visual observations are recorded in manifest.json. Photos are not bundled.

FILES
textures/: Base-color, normal and roughness PNGs; 512 x 512 pixels each.
manifest.json: Stable finish IDs, units, physical tile scales, evidence and limits.
material-board.jpg: A quick visual reference to the twelve finishes.
material-library.js: Three.js loader and scale-aware geometry UV helper.
tools/build-materials.py: Reproducible original authoring source (Python, NumPy, Pillow).

WEB
Use material-library.js as in the Apple Hill project. It expects the local Three.js
module at ./assets/three.module.js and catalog at ./assets/materials/catalog.js.
Apply library.uv(geometry,material.userData.tileSizeFt) before creating a mesh.
Model dimensions are feet; texture tile sizes are also feet. Dispose the library
when unloading a scene. Retain Three.js's MIT license if bundling that library.

BLENDER
Use Principled BSDF. Base color: sRGB. Normal and roughness: Non-Color.
Connect normal RGB through a Normal Map node (OpenGL/+Y tangent convention).
Use the metalness and normal-strength values in manifest.json. Roughness map
already includes its overall roughness; use a multiplier of 1, not the nominal
roughness value a second time. Set a tile to tile_size_ft * 0.3048 metres.
The supplied maps carry only small surface relief. Never infer physical pipe
diameter, structural cracks or material condition from them.

REUSE
Keep stable AH-MAT IDs for this Apple Hill library. Reuse finish definitions and
visual language at other control points, while keeping property evidence,
equipment identities and hydraulic records separate. Attach new local evidence
before claiming the finish is correct for another asset. Material reuse does not
establish shared construction or a connection between systems.

EVIDENCE / LIMITS
The photo palette includes weathered concrete, light walk concrete, red-brown
garage brick, dark asphalt, autumn turf, earth, aged copper, galvanized metal,
black polymer, blue pressure-tank enamel, yellow handles and access iron.
Deep tank construction, road widths, garage facade bays, water levels, pipe
sizes and hidden transitions remain schematic. Green valve-box covers are
excluded from the rendered scene. NETAFIM and WELL-X-TROL are source-visible
manufacturer/product-family marks, not inferred exact models.

RIGHTS
Original procedural maps and authoring source were created for this project.
Underlying site photographs were supplied by the user and remain evidence,
not a texture redistribution. Third-party logos and libraries are not included
in this package.
