"""Bake original, repeatable PBR tiles informed by the supplied Apple Hill photos.

No photograph is pasted onto a model. These are authored surface approximations,
not photogrammetry or measured material scans. Geometry stays in feet.
"""
from pathlib import Path
import hashlib, json, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist/assets/materials'
OUT.mkdir(parents=True, exist_ok=True)
N = 512
Y, X = np.mgrid[0:N, 0:N] / N
rng = np.random.default_rng(18473)

def noise(seed, octaves=5):
    r = np.random.default_rng(seed)
    a = np.zeros((N, N), dtype=float)
    # Integer frequencies make every tile periodic across its boundary.
    for k in range(octaves):
        f = 2 ** k
        for _ in range(7):
            ix, iy = r.integers(-f, f + 1, 2)
            if ix == iy == 0: ix = 1
            a += np.cos(2 * math.pi * (X * ix + Y * iy) + r.random() * 2 * math.pi) / (1.9 ** k)
    return (a - a.mean()) / max(a.std(), .001)

DEFS = [
 ('concrete-weathered','Weathered cast concrete','#aaa99b',.94,0,4,.035,'assembly.jpg','WG-3 pale grey cast concrete, pores, formwork seams and vertical damp staining. Stains are generalized; not an inspection of deterioration.'),
 ('concrete-walk','Light concrete walkway','#c5c3b5',.9,0,4,.014,'well.png','Light warm-grey walking surface with fine aggregate. Joint spacing is illustrative.'),
 ('brick-red','West Garage red-brown brick','#795044',.9,0,4,.018,'non-irrigation-overview.jpg','Garage red-brown brick infill between pale concrete bands. Brick scale and facade openings remain schematic.'),
 ('asphalt','Road asphalt','#505452',.98,0,6,.022,'tank.png','Dark-grey road beyond the lawn. Road width and markings are context only.'),
 ('turf-autumn','Autumn lawn','#68774b',.98,0,4,.025,'well.png','Mixed olive/green turf with tan leaf litter from the November site photos. Leaf density is representative.'),
 ('soil','Exposed earth','#90765a',1,0,3,.035,'well.png','Brown soil/mulch visible at planted edges. Deep soil layering is illustrative.'),
 ('copper-aged','Aged copper pipe','#79574a',.48,.72,1,.003,'assembly.jpg','Reddish-brown pipe with muted oxidation in the WG-3 assembly. Finish observed; pipe diameter is not measured.'),
 ('galvanized','Galvanized metal','#a6aca6',.48,.76,2,.002,'assembly.jpg','Dull silver-grey conduit, couplings and fittings. Metal grain is synthesized.'),
 ('polymer-black','Black polymer housing','#262d2b',.56,0,1,.002,'filter.jpg','Matte black NETAFIM filter housing and dark pipe fittings; no exact product model inferred.'),
 ('enamel-blue','Blue pressure-tank enamel','#148dbd',.34,.12,1,.001,'components.jpg','Bright blue WELL-X-TROL pressure tank visible in WG-3. Color is photo-informed, not color calibrated.'),
 ('valve-yellow','Yellow valve handle','#c5ab35',.43,.15,1,.001,'components.jpg','Yellow lever handles on the WG-3 ball valves.'),
 ('iron-access','Weathered access iron','#635950',.84,.58,2,.008,'non-irrigation-overview.jpg','Brown cast-metal tank access covers. This material is for tank accesses, never green valve-box covers.'),
]

manifest={'name':'Apple Hill surface library','version':'1.0.0','units':'feet','resolution':[N,N],
 'method':'Original periodic procedural maps authored from visual photo analysis. Not scanned or extracted photographic textures.',
 'color_space':{'basecolor':'sRGB','normal':'linear, OpenGL +Y','roughness':'linear'},
 'reuse':'Reuse finish IDs and scale at other control points; attach that area’s own evidence before claiming its materials match.',
 'geometry_limit':'These materials establish no dimensions, underground routes, condition ratings, equipment identity or performance.',
 'materials':[]}
previews=[]
for i,(key,name,color,rough,metal,tile,bump,source,observation) in enumerate(DEFS):
    n=noise(920+i); fine=noise(1920+i,8)
    base=np.array(tuple(bytes.fromhex(color[1:])),dtype=float)
    h=n*.1+fine*.035
    rgb=np.broadcast_to(base,(N,N,3)).copy()+n[:,:,None]*3+fine[:,:,None]*1.8
    if key=='concrete-weathered':
        bands=np.cos(2*math.pi*X*9+noise(44)*.15)*.5+.5
        damp=(noise(55)>0)*np.maximum(0,bands-.3)*(.3+.7*Y)
        rgb-=damp[:,:,None]*np.array([18,16,18]);h-=damp*.06
        pores=rng.random((N,N))>.994
        rgb[pores]*=.65;h[pores]-=.25
    elif key=='concrete-walk':
        speck=rng.random((N,N));rgb[speck>.975]-=25;rgb[speck<.035]+=13
        h+=(speck-.5)*.07
    elif key=='brick-red':
        row=np.floor(Y*16).astype(int);col=np.floor(X*5+(row%2)*.5).astype(int)
        bx=(X*5+(row%2)*.5)%1;by=(Y*16)%1
        mortar=(bx<.04)|(by<.14)
        variation=np.sin(col*14.7+row*8.91)*9
        rgb+=variation[:,:,None];rgb[mortar]=[156,148,129];h[mortar]-=.7
    elif key=='asphalt':
        aggregate=rng.random((N,N));rgb+=(aggregate[:,:,None]-.5)*22;h+=(aggregate-.5)*.3
    elif key=='turf-autumn':
        rgb=np.broadcast_to(base,(N,N,3)).copy()+n[:,:,None]*1.4+fine[:,:,None]*1.2;h=fine*.015+np.sin(2*math.pi*(X*99+Y*22))*.012
        im=Image.fromarray(np.uint8(np.clip(rgb,0,255)));d=ImageDraw.Draw(im)
        for j in range(210):
            cx,cy=rng.integers(0,N,2);a=rng.random()*math.tau;l=rng.uniform(2.5,6);w=l*.45
            pts=[(cx+math.cos(a)*l,cy+math.sin(a)*l),(cx-math.sin(a)*w,cy+math.cos(a)*w),(cx-math.cos(a)*l,cy-math.sin(a)*l),(cx+math.sin(a)*w,cy-math.cos(a)*w)]
            d.polygon(pts,fill=['#a08c59','#968054','#b2a077','#75663f'][j%4])
        rgb=np.asarray(im,dtype=float)
    elif key=='soil':
        rgb=np.broadcast_to(base,(N,N,3)).copy()+n[:,:,None]*2+fine[:,:,None]*2;h=n*.025+fine*.025
    elif key=='copper-aged':
        pat=np.clip(n-.5,0,1)[:,:,None];rgb=rgb*(1-pat*.28)+pat*np.array([30,37,25])
        h+=np.cos(2*math.pi*Y*120)*.012
    elif key=='galvanized':
        rgb+=np.round(n*2)[:,:,None]*4;h+=fine*.013
    elif key=='iron-access':
        h+=np.sin(2*math.pi*X*30)*np.sin(2*math.pi*Y*30)*.08
        rgb+=n[:,:,None]*5
    elif key in ['polymer-black','enamel-blue','valve-yellow']:
        rgb=np.broadcast_to(base,(N,N,3)).copy()+fine[:,:,None]*.8;h=fine*.015
    rough_pixels=np.clip(rough*255+fine*5,0,255).astype('uint8')
    # Height-derived tangent-space normals; wrap gradients at the tile edges.
    dx=(np.roll(h,-1,axis=1)-np.roll(h,1,axis=1))*.65
    dy=(np.roll(h,-1,axis=0)-np.roll(h,1,axis=0))*.65
    normal=np.stack([-dx,dy,np.ones_like(dx)],axis=2);normal/=np.linalg.norm(normal,axis=2)[:,:,None]
    normal=np.uint8(np.clip((normal*.5+.5)*255,0,255))
    baseimage=Image.fromarray(np.uint8(np.clip(rgb,0,255)))
    baseimage.save(OUT/f'{key}-basecolor.png',optimize=True)
    Image.fromarray(rough_pixels).save(OUT/f'{key}-roughness.png',optimize=True)
    Image.fromarray(normal).save(OUT/f'{key}-normal.png',optimize=True)
    item={'id':'AH-MAT-'+str(i+1).zfill(2),'key':key,'name':name,'tile_size_ft':tile,'roughness':rough,'metalness':metal,'normal_strength':.12 if key in ['turf-autumn','soil'] else .25 if metal else .3,'height_scale_ft':bump,'source_photo':'../'+source,'source_sha256':hashlib.sha256((ROOT/'dist/assets'/source).read_bytes()).hexdigest(),'evidence_status':'photo-informed visual approximation','observation':observation,'maps':{'basecolor':f'{key}-basecolor.png','normal':f'{key}-normal.png','roughness':f'{key}-roughness.png'}}
    manifest['materials'].append(item);previews.append((item,baseimage))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
(OUT/'catalog.js').write_text('export const materialCatalog='+json.dumps(manifest,indent=2)+';\n',encoding='utf8')
sheet=Image.new('RGB',(1200,1050),'#f4f3ed');g=ImageDraw.Draw(sheet)
fontpath='C:/Windows/Fonts/arial.ttf'
title=ImageFont.truetype(fontpath,34);font=ImageFont.truetype(fontpath,19);small=ImageFont.truetype(fontpath,14)
g.text((32,25),'APPLE HILL / MATERIAL LIBRARY 01',fill='#263a34',font=title)
g.text((32,73),'Photo-informed finishes · Original tiling maps · Model units: feet',fill='#657266',font=font)
for i,(item,im) in enumerate(previews):
    x=32+(i%4)*294;y=125+(i//4)*295
    sheet.paste(im.resize((270,213)),(x,y));g.text((x,y+224),item['id']+'  '+item['name'],fill='#263a34',font=small)
    g.text((x,y+246),f"Tile {item['tile_size_ft']} ft · Roughness {item['roughness']}",fill='#657266',font=small)
g.text((32,1010),'Surface approximations, not measured scans. Apply only where local evidence supports the finish.',fill='#657266',font=small)
sheet.save(OUT/'material-board.jpg',quality=92)
print(f'Baked {len(DEFS)} original material sets and evidence manifest to {OUT}')
